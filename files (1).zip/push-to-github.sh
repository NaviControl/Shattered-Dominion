#!/usr/bin/env bash
# Pushes the Shattered Dominion snapshot to a feature branch so GitHub Actions runs CI.
# The default branch is not touched. Shows the diff and asks before pushing.
#
# Usage: ./push-to-github.sh <repo-url> <extracted-snapshot-dir>
# Example:
#   unzip kingdom-conquest-iii-100-territories.zip -d snapshot
#   ./push-to-github.sh https://github.com/NaviControl/Shattered-Dominion.git ./snapshot
set -euo pipefail

REPO_URL="${1:?usage: $0 <repo-url> <snapshot-dir>}"
SNAPSHOT="$(cd "${2:?usage: $0 <repo-url> <snapshot-dir>}" && pwd)"
BRANCH="feature/100-territories"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

echo "Cloning $REPO_URL ..."
git clone --quiet "$REPO_URL" "$WORK/repo"
cd "$WORK/repo"

DEFAULT="$(git symbolic-ref --short refs/remotes/origin/HEAD | sed 's#^origin/##')"
echo "Default branch: $DEFAULT"
git checkout --quiet -B "$BRANCH" "origin/$DEFAULT"

# Make the working tree match the snapshot exactly, keeping .git.
find . -mindepth 1 -maxdepth 1 ! -name .git -exec rm -rf {} +
cp -a "$SNAPSHOT"/. ./
git add -A

if git diff --cached --quiet; then
  echo "No differences from $DEFAULT. Nothing to push."
  exit 0
fi

echo
echo "Changes that will be pushed to origin/$BRANCH:"
git diff --cached --stat | tail -n 25
echo
read -r -p "Push to origin/$BRANCH? [y/N] " answer
case "$answer" in
  y|Y) ;;
  *) echo "Aborted. Nothing was pushed."; exit 1 ;;
esac

git commit --quiet -m "100-territory deterministic world, CI workflow, test updates"
git push -u origin "$BRANCH"
echo
echo "Pushed. CI runs on the push. Check the Actions tab of the repository."
