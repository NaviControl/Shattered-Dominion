# NAVI-SD-OMEGA-001 — CR-002 REV1: Creature-Only Combat Rules

**Status:** DESIGN PROPOSAL for approval. Nothing here is implemented.
**Supersedes:** all troop-based combat in the prototype and in the solo simulation (`src/sim/engine.ts`).
**Authority granted:** design and specification only. Source-code changes require a separate approval after these rules, the schema (REV1-schema) and the migration plan (REV1-migration) are approved.

Items marked **[DECIDE]** need an owner decision. Items marked **[NEW]** have no source in the prototype and need approval before use.

---

## 1. Invariants (new)

1. Creatures are the only battlefield combatants.
2. An army occupies at most 15 positions on a 5 × 3 grid.
3. Creatures fight autonomously within the rules below. The player's commands are deployment and a limited set of commander actions.
4. Troops, battalions, the 9,999 troop cap and the 15-point card budget do not exist in new combat.
5. No separate numerical deployment cost exists. Formation slots are the only creature-capacity constraint.
6. Combat is deterministic: integer arithmetic, fixed ordering, no random draws.

Retained from prototype: the 100 × 100 world and its coordinates, the staging concept (radius to be decided, §12), tower victory (hold 4 of 6), and the save-compatibility policy (no silent corruption).

## 2. Formation grid

- 5 columns (`c` = 0..4) by 3 rows (`r` = 0..2). 15 positions.
- **[DECIDE A3]** Row `r` = 0 is the front, facing the enemy. Proposed.
- A creature occupies a footprint of connected positions. Its anchor is the top-left cell of the footprint.
- Placement is legal only if every footprint cell is inside the grid, no two creatures overlap, and the total occupied positions across the army do not exceed 15.
- An army may have fewer creatures than positions. Empty positions are allowed.

## 3. Size classes and footprints

Five physical size classes. Footprints range from 1 to 6 connected positions, as specified.

| Size class | Footprint (positions) | v1 shape (horizontal only) | Status |
| :--- | :--- | :--- | :--- |
| Small | 1 | 1 × 1 | **[DECIDE A1]** provisional |
| Medium | 2 | 1 × 2 | **[DECIDE A1]** provisional |
| Large | 3 | 1 × 3 | **[DECIDE A1]** provisional |
| Huge | 4 | 2 × 2 | **[DECIDE A1]** provisional |
| Colossal | 6 | 2 × 3 | **[DECIDE A1]** provisional |

- **[DECIDE A1]** Footprint count per class. The table above is a provisional mapping that spans 1–6 with five classes; footprint 5 is unused. The owner should confirm or replace it.
- **[DECIDE A2]** Shape set. v1 allows horizontal rectangles only, with no rotation. Confirm, or name the permitted shapes.
- **Assignment** of each of the 432 creatures to a size class is an SD-05 deliverable and is **not** set by this document.
- A multi-position creature is one combat entity: one HP pool, one attack, one set of cooldowns, one turn per round.

## 4. Creature attributes

| Attribute | Source | Status |
| :--- | :--- | :--- |
| HP, ATK, DEF, SPD at levels 1–50 | `creatureBalance.calculateCreatureStatsAtLevel`, exported as `creature_stat_table.json` | **Existing.** Authoritative for stats. |
| Initiative | SPD | Derived. Higher SPD acts first. Ties go to the lower instance id. |
| Movement (cells per round) | — | **[NEW]** SD-05 assigns per creature. |
| Range (cells, Manhattan) | — | **[NEW]** SD-05 assigns per creature. |
| Basic attack | Uses ATK | **[NEW]** rule in §8. |
| Active skills (with cooldowns) | Names only (48 signature abilities) | **[NEW]** effects defined in SD-05. |
| Passive abilities | Family specialty text (12) | **[NEW]** triggers and effects defined in SD-05. |

A creature with no defined active skill has none. Nothing is invented for it.

## 5. Round structure

Combat runs in rounds, up to `R_MAX` rounds **[DECIDE A9]**.

1. **Round start.** Every cooldown decreases by 1, with a floor of 0. `round_start` passives fire, in the order defined in §11.
2. **Turns.** Every living creature takes one turn, in initiative order: SPD descending, then instance id ascending.
3. **Death.** A creature at 0 HP is removed immediately. `on_death` passives fire at once.
4. **Round end.** The battle checks victory (§13).

### 5.1 A creature's turn

1. **Skill.** If an active skill is off cooldown and its trigger and target conditions are met, use it. Skills are checked in their defined slot order. A skill that resolves sets its cooldown.
2. **Attack.** If no skill was used and a target is in range, make a basic attack.
3. **Move.** If no attack was made, move toward the nearest enemy (§7), then **[DECIDE A10]** attack if a target is now in range. Proposed: move-then-attack is allowed.

## 6. Target selection (deterministic)

- Legal targets are living enemy creatures.
- Distance `d(a, t)` is the minimum Manhattan distance between any cell of the attacker's footprint and any cell of the target's footprint.
- Pick the target with the smallest `d`. Ties break by the target's anchor row (lower first), then anchor column (lower first), then instance id (lower first).
- Skills with a targeting rule use the same tie-break after applying their own filter.

## 7. Movement

- A creature moves one cell at a time. Its anchor steps to a 4-neighbour such that the whole footprint is inside the grid and does not overlap any living creature.
- Creatures cannot pass through enemies. Allies cannot share cells. Swapping is not allowed in v1.
- Path: breadth-first search over legal anchors, to the nearest cell from which the target is in range. Ties break by the fixed direction order up, down, left, right.
- A creature moves at most its movement value per turn. It stops early if no step reduces its distance to the nearest enemy. Movement that cannot reduce distance does not happen.

## 8. Basic attack and damage **[NEW — DECIDE A5]**

The prototype has no creature damage formula. This is proposed. It must be approved before use.

```
raw       = max(0, ATK_attacker − DEF_defender)
elem_bps  = 10000 × (1 + element_value)     // from the element matrix, if approved (§9)
fam_bps   = 10000 × (1 + family_value)      // from the family matrix, if approved (§9)
mult_bps  = elem_bps × fam_bps / 10000      // integer division
damage    = max(1, raw × mult_bps / 10000)  // integer division; minimum 1
HP        = max(0, HP − damage)
```

- With neutral matchups (both values 0), `damage = max(1, ATK − DEF)`.
- Best combined case (1.20 × 1.12 = 1.344) and worst case (0.85 × 0.90 = 0.765) come from the existing `combat_rules.csv`. The same integer formula produces them.
- **[DECIDE A5]** Whether the matchups are approved. Until they are, `mult_bps` is 10000.

## 9. Element and family matchups **[DECIDE K4]**

- Source: `element_matchups.csv` and `family_matchups.csv`. These are exported but used by no prototype code. Their own status note says "PROPOSED."
- They become combat-active only through a separate approval after balance QA.
- **Army synergies** from `creatureBalance.calculateCreatureSynergies` (existing) apply at battle start. Element tiers: 2 minor (+10% power), 3 major (+20%), 4 primal (+30%). Family bonus: 2 or more of a family.
- **[DECIDE]** Which synergy stats are combat-active in v1. Proposed: ATK, DEF and SPD only. Crit, lifesteal and dodge are not implemented in v1 and are deferred.

## 10. Active skills and cooldowns

- Cooldowns are measured in **rounds**. **[DECIDE A4]** The prototype measures commander cooldowns in **seconds** (`CardSkill.cooldown`). These units are incompatible. Rounds are proposed for creatures; the commander cooldown conversion needs a decision.
- Each skill has an effect type drawn from an enumerated set (damage, heal, buff, debuff, move). An effect is a parameter set. No effect is defined without an SD-05 entry.
- A skill can be used once per turn. Skills resolve in slot order, and a skill that fails its condition does not use its cooldown.

## 11. Passive abilities

- Triggers: `battle_start`, `round_start`, `on_attack`, `on_hit`, `on_damaged`, `on_death`, `aura` (continuous, while the source is alive and in range).
- Evaluation order: by trigger in the order above, then by instance id.
- A passive's effect uses the same enumerated effect types as skills.

## 12. (Superseded by owner decision) Commanders, staging and garrisons

Owner decision: there are no commanders and no troops. Creatures are the only combatants. Staging and rosters below apply to creatures only.

- **Commanders are not combat units.** They do not occupy formation positions **[DECIDE A7]**. Proposed: a commander sits outside the grid.
- Commander contributions, all non-troop:
  - **Leadership aura**: a fixed buff to creatures at battle start (values from SD-05).
  - **Strategic ability**: one per battle, with a cooldown in rounds.
  - **Creature synergy**: existing `calculateCommanderCreatureBond` (element affinity match, 1–3+ matches) is applied at battle start.
- Commanders never generate troops and never deal troop-based damage.
- **Staging.** An army is assembled from creatures stationed on owned tiles within the staging radius of its origin. **[DECIDE A8]** Keep radius 2 from the troop model, or change it. The creature roster per tile is a new rule and needs approval.
- **Tile defence.** A tile's defence is the creatures stationed on it. The troop-based `garrisonTroops` value is retired. Tile creature rosters need a rule, and that is a blocker for migration (see the migration plan).

## 13. Victory, defeat and capture

- A battle ends when one side has no living creatures, or when `R_MAX` rounds have passed.
- **Attacker wins** if the defender has no living creatures. **Defender holds** if the attacker has none.
- **Timeout tiebreak [DECIDE A9]:** proposed, the side with the greater share of remaining HP, compared with integer cross-multiplication. Equal shares: defender holds.
- **Capture [DECIDE A8]:** if the attacker wins, the tile changes owner. The surviving attackers become the tile's creature roster. Proposed.
- **Tower victory** is unchanged: hold 4 of the 6 mythical towers.

## 14. Determinism

- All arithmetic is integer. Ordering uses ordinal comparison on ids.
- No random draws in combat v1. Any future random effect needs a named, seeded stream.
- Each round produces an event log entry, and the state hash is recorded per round, so the Unity port can be checked round by round.

## 15. Validation

Every army and every battle state must satisfy:

- All footprints inside the grid and non-overlapping.
- Occupied positions ≤ 15.
- Size class matches footprint size (§3).
- Instance ids unique within the army.
- A creature belongs to at most one army at a time.
- Levels 1–50. Cooldowns are non-negative integers.
- Only enumerated effect types are used.
- No troop, battalion, cap or point-budget fields exist in the new state.

## 16. Decision list (for approval)

| ID | Decision | Proposed |
| :--- | :--- | :--- |
| A1 | Footprint count per size class | 1, 2, 3, 4, 6 |
| A2 | Permitted shapes | Horizontal rectangles, no rotation |
| A3 | Which row is the front | Row 0 |
| A4 | Cooldown unit | Rounds (commander seconds to convert) |
| A5 | Damage formula and matchup approval | §8 formula; matchups off until approved |
| A7 | Commanders on the grid | No, outside the grid |
| A8 | Staging radius; tile rosters; capture survivors | Radius 2; survivors become roster |
| A9 | Round cap and timeout tiebreak | To be set; tiebreak by HP share |
| A10 | Move-then-attack | Allowed |
| A11 | Save key and retention | See migration plan |
| K4 | Matchup authority | Off until approved |

Assignment of size classes, movement, range, skills and passives for all 432 creatures is an SD-05 deliverable, reviewed separately.


## 17. Owner updates (creatures only; eight baseline stats)

- **No troops, no commanders.** Creatures are the only combatants. The troop increase, the 9,999 cap and the commander effects are not part of the design.
- **Eight baseline stats, raised on each level-up:** HP, attack, defense, speed, movement, range, skill power and team synergy. Skill power and team synergy are multipliers (basis points, 10000 = 100%). Movement and range are the SD-05 values.
- **Level-up points:** each level grants points that the player allocates freely across the eight stats. The points per level is not yet decided; the allocation must spend every point. Implemented in `src/combat/stats.ts`.
- **Team synergy bonus:** from the prototype's element and family synergies, applied at battle start. Each creature's team-synergy stat scales its share.
- **Skills:** every creature has an active skill and a passive from the approved data. Whether each creature should get more than one active is open (the schema allows up to two).
