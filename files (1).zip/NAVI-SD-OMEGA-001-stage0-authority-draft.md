# NAVI-SD-OMEGA-001 — Stage 0 Authority Package (DRAFT)

**Status:** DRAFT. Not approved. Not frozen. No child may act on this document until a human approves a frozen version.
**Enforcement level:** CONTRACT-ONLY. Nothing in this package is technically enforced. Child agents are bound by instruction, and compliance is checked after the fact by the deterministic checks in Section 6. Do not describe this campaign as "NAVI ENFORCED."
**Repository:** https://github.com/NaviControl/Shattered-Dominion.git
**Repository access at drafting:** NOT ACCESSIBLE. GitHub blocked automated access (robots policy), and no mirror or search result exposed the contents.
**Baseline revision:** UNRESOLVED
**Branch / worktree:** UNRESOLVED
**Contract digest:** UNBOUND
**Human approval:** PENDING

---

## 1. Parent objective

Turn the existing Shattered Dominion prototype into a cohesive, browser-playable fantasy strategy game with continuous 3D geography, 100 reproducible, individually conquerable territories, creature collection, commanders, tactical combat, progression, and a modern interface. Execute as one coordinated campaign with child missions, dependency-aware sequencing, frozen shared interfaces, and independent verification.

## 2. Stage 0 work performed (read-only)

- Inventoried 7 uploaded data files (creature catalog, rarity table, two matchup matrices, combat rules, collection hierarchy).
- Verified: 432 unique creature IDs; tier counts 168/120/72/36/24/12; pull rates sum to 100%; Mythical 0.5% total; 12×12 element and family matrices; combat multiplier extremes 1.344 and 0.765.
- Noted: the two creature CSVs are identical except for a byte-order mark; keep one as canonical.
- Not performed: any inventory of source code, assets, tests, or dependencies (repository not accessible).

## 3. Protected invariants (proposed, to confirm against the repository)

- Territory ID scheme and square-based conquest rules. Superseded by CR-001 (integer coordinates 0..100, 10,201 territories), pending approval.
- Existing player collection and saved progress; `kc3_sovereign_save_v6` compatibility or a verified migration.
- Existing functioning GLB loader and fallback architecture.
- Existing renderer, `RealmMap.tsx`, `assetManifest.ts`, `initialData.ts`, until replacements are proven compatible.
- No changes to economy, combat, or rarity values except through an approved data change.
- No alteration of tests or verification policy by any builder.

## 4. Child mission registry

Ownership below is a proposal based on the target folder structure. Exact file lists require repository access and are UNRESOLVED.

| Child | Scope | Proposed write scope | Status |
|---|---|---|---|
| SD-01 | Infrastructure and architecture | `docs/`, `scripts/`, build and CI config | Not started |
| SD-02 | World rendering and geography | `src/rendering/terrain/`, `src/rendering/camera/` | Not started |
| SD-03 | Territory conquest and economy | `src/game/conquest/`, `src/game/economy/` | Not started |
| SD-04 | Combat and army systems | `src/game/combat/` | Not started |
| SD-05 | Creatures, commanders, balance | `src/game/creatures/`, `src/game/commanders/`, `src/data/` | Not started |
| SD-06 | 3D assets and animation | `public/assets/`, `src/rendering/assets/` | Not started |
| SD-07 | UI, UX, onboarding | `src/ui/`, `src/components/` | Not started |
| SD-08 | Integration, performance, QA | `tests/` (new tests only) | Not started |
| SD-V | Verification | Read-only against all paths; writes only to `navi/verification/` | Not started |

Rules for every child:
- Write only inside its declared scope. Any write outside it is a stop condition.
- Shared interfaces (`WorldTile`, `Creature`, `BattleState`, save format) are frozen before SD-02 through SD-07 begin. Changing one requires a new approved contract.
- A child may not modify its own contract, widen its scope, or grant itself tools.
- Each child produces a receipt: files changed, commands run, test output, and a list of any stop conditions hit.

## 5. Resource limits (proposed)

- Maximum concurrent builders: 4. Verifier: 1.
- Maximum repair iterations per child: 2, then escalate to the human.
- External spending: $0 without separate written approval.
- Paid model or API usage: requires an explicit budget.
- External downloads: only from separately approved sources.
- Deployment and publication: prohibited under this contract.
- Merge to protected branches: prohibited under this contract.
- Repository deletion, force-push, or destructive reset: prohibited.

## 6. Verification and post-hoc enforcement

Because no runner enforces scope, verification must be deterministic and must not be performed by an AI agent. Required checks, each producing a pass/fail record:

1. **Baseline hash.** Record the full tree hash at the approved baseline revision before any child starts.
2. **Scope diff.** After each child, compare changed paths against that child's allowlist. Any path outside it fails the child.
3. **Protected-path check.** Fail if any protected invariant path (Section 3) changed without an approved contract change.
4. **Build and type check.** TypeScript compile and production build must succeed.
5. **Automated tests.** Full test suite must pass; no test may be deleted or skipped to pass.
6. **Data validation.** Creature catalog: 432 records, unique IDs, rarity counts match the rarity table, pull rates sum to 100%.
7. **Save compatibility.** Load a saved file from the baseline and confirm it loads or migrates without data loss.
8. **Browser run.** Scripted load of the build with screenshots and console-error capture.

AI review of diffs or screenshots may be attached as advisory notes. It never determines pass or fail.

Independent verifier: a scripted checker that runs the checks above and writes results to `navi/verification/`. It must not be able to edit builder output or approve its own results. The human owner decides ACCEPT, DECLINE, or REWORK.

## 7. Stop conditions

Stop the affected workstream on any of the following:

- A write outside the child's allowlist.
- A changed baseline or a protected path changed without approval.
- Conflicting outputs between children.
- Any failed deterministic check.
- Unexpected network access, spending, or new dependency.
- Exposed credentials.
- More than 2 repair iterations on one child.

Unaffected workstreams may continue only if they are already authorized.

## 8. Open items before freezing

1. Repository access: a zip export or file listing uploaded to the workspace, or the repository made readable. Needed to set the baseline hash and the exact child allowlists.
2. Baseline revision and target branch.
3. Confirmation of the proposed child ownership in Section 4.
4. Human confirmation of the resource limits in Section 5.
5. Choice of execution host. Under contract-only mode, the host is not enforcing anything; this should be recorded as such.
6. Canonical creature CSV (the two uploads are identical apart from a byte-order mark).
7. Known data-label issue: the rarity table's "Expected Pulls per Tier" column is the expected pulls to hit that tier once, not per creature. Relabel before use.
8. Territory count change, 72 to 100. This changes a protected invariant and needs an approved contract change. Before approving, confirm: (a) the existing 72-territory renderer and its territory data, which must be migrated or replaced; (b) whether saves such as `kc3_sovereign_save_v6` reference territory IDs, and if so how they migrate; (c) the acceptance criterion "72 selectable territories" must be updated to match; (d) define "reproducible," for example deterministic generation from a fixed seed, and state the seed policy; (e) how the 100 territories are assigned to the four biomes.

## 9. Acceptance

The mission is complete only when the game meets the approved acceptance criteria and the deterministic checks in Section 6 pass with recorded evidence. Acceptance does not authorize deployment, publication, or merging into a protected branch.

---

## Revision CR-002 REV1: Creature-Only Combat (parent mission and child contracts)

**Status:** Design and specification update only. Stopped for approval. No unrestricted source-code changes are authorized.
**Decision:** Approved design direction — creature-only combat. Documents: CR-002 REV1 rules, CR-002 REV1 schema, CR-002 REV1 migration plan.

### Revised protected invariants

- **Removed (superseded):** 9,999 troop cap; 15-point card budget; battalion and support combat; troop-based attacks; troop garrisons; staging by troop count; the troop model in the solo simulation.
- **Added:** creatures are the only battlefield combatants; an army occupies at most 15 positions on a 5 × 3 grid; creature size classes 1–6 positions; deterministic creature-only combat; commanders are not combat units and do not generate troops; no separate numerical deployment cost.
- **Retained:** the 100 × 100 world and tile ids; tower victory (hold 4 of 6); the save-compatibility policy (no silent corruption; v6 readable; no legacy deletion before gates G1–G8).

### Child contract changes

| Child | Revised scope | Notes |
| :--- | :--- | :--- |
| **SD-01** Infrastructure | Owns the shared `creature-combat/1` schema, the v7 save key and the migration module (design only). | Migration code is not written until approved. |
| **SD-02** World rendering | Tile markers show creature rosters, not troop counts. | No change to terrain. |
| **SD-03** Territory conquest | Armies are creature placements. Staging by creatures (A8). Tile rosters. Capture rule (A8). Tower victory unchanged. | Retire troop-based dispatch. |
| **SD-04** Combat engineering | Designs the deterministic creature-only combat: round structure, target selection, movement, basic attack, skills with cooldowns, passives, victory, determinism, event hashing. | Owns the rules document. Implementation after approval. |
| **SD-05** Creature design and balance | Assigns size class, footprint, movement, range, active skills and passives for the 432-creature roster. Uses `creatureBalance.ts` stats as the starting point. **Identifies and replaces troop-dependent formulas**, including commander `troopCapacity` and `troopYieldIndex`. | Produces versioned data, reviewed separately. Stats are not changed. |
| **SD-06** 3D assets | Creature models mapped to size classes; footprint visuals. | Depends on SD-05 sizes. |
| **SD-07** UI and onboarding | 5 × 3 formation editor. Retire battalion and support slots, the points budget, the barracks troops tab, and troop text. Roster view replaces recruitment. | Depends on A1–A3. |
| **SD-08** Integration and QA | Tests for combat determinism and migration gates G1–G8. Golden combat replay after approval. | — |
| **SD-V** Verifier | Adds: schema validation (V1–V9), footprint legality for every assignment, no `troop*` fields in v7, golden combat replay. Troop checks kept until replaced. | Deterministic only; no AI judgement. |

### Limits (unchanged)

Stop conditions, resource limits and the verification rules in the original Stage 0 draft stand. Launching, deploying and merging to protected branches remain prohibited.

### Authority

This revision authorizes design and specification updates. Implementation waits for approval of the complete combat rules, the schema and the migration plan.
