# NAVI-SD-OMEGA-001 — Change Request CR-001: World Coordinates and Territory Scale

**Status:** APPROVED for scope (owner, 2026-11-05). Core world and simulation implemented. Rendering, storage and client migration remain open (section 10).
**Parent contract:** NAVI-SD-OMEGA-001 (Shattered Dominion)
**Reason:** Owner directive to replace the 200×200 territory specification with integer coordinates 0..100 inclusive (10,201 territories) and to design for eventual 250×250 expansion.

---

## 1. Directive (as received)

- Initial release: integer coordinates from (0,0) through (100,100), inclusive. 101 × 101 = **10,201** territories.
- Each coordinate is one authoritative territory with its own unique ID, ownership, garrison, resources and conquest state.
- Four primary biome regions: Sol Heights (NW), Ignis Caldera (NE), Frost Wastes (SW), Abyssal Marshes (SE). Biome visuals transition across boundaries.
- Continuous 3D terrain with chunk-based rendering and LOD. No 10,201 permanent Three.js meshes.
- Square-based conquest, movement and selection stay independent of terrain geometry.
- Backward compatibility with the 72-territory prototype through a verified migration.
- Coordinate system must extend to (250,250) without generating those territories now.
- Verify indexing, storage, rendering performance and save migration before implementation. Stop for approval if the change exceeds authorized scope.

## 2. Scope determination

This change **exceeds the authorized scope** and requires approval. It alters:

| Protected item (Stage 0 §3) | Change |
| :--- | :--- |
| 72 territory IDs and square-based rules | 72 → 10,201 territories; ID scheme changes |
| Save format `kc3_sovereign_save_v6` | Requires v7 with delta storage and migration |
| Existing renderer | Replaced by chunked terrain and instancing |
| Simulation engine | Needs a spatial index before it can run at this scale |

It also adds a tile type (`mythical_tower`) and a new win condition.

## 3. Verified measurements (this environment)

| Check | Result | Consequence |
| :--- | :--- | :--- |
| Grid size | 101 × 101 = 10,201 | Confirmed |
| Biome split, middle row/column assigned to one side (`x<50`, `y<50`) | NW 2,500 · NE 2,550 · SW 2,550 · SE 2,601 | Regions are not equal. A rule for the centre line is needed (Decision D2). |
| Minimal tile JSON, 10,201 tiles (id, x, y, biome, owner, troops, maxTroops, power) | 1.09 MB | The prototype's full tile record is larger. Storing every tile in one save risks the browser storage quota. |
| Simulation tick at 10,201 tiles (current engine: clone per tick, linear scans) | 6.9 ms/tick | Full match of ~1,200 ticks ≈ 8 s of compute. Acceptable for a prototype, but the neighbour and staging queries scan every tile (0.15 ms each). A spatial index is required before multiplayer. |
| Rendering performance | **Not measured.** No GPU or browser available here. | Must be verified in a browser before approval of the rendering design (Section 6). |

## 4. Coordinate system

- **Territory ID:** `t_<x>_<y>` (e.g. `t_50_50`). The ID does not depend on grid width, so it stays stable when the world grows to 250×250.
- **Storage index:** `y * width + x`, where `width` is a world property (101 now, 251 later). Only the index depends on width.
- **Bounds:** `0 ≤ x < width`, `0 ≤ y < height`. Out-of-range coordinates are rejected.
- The current prototype IDs `tile_<row>_<col>` map to `t_<col>_<row>`. This is a pure rename, applied to tiles, armies (`from`/`to`), and any saved references.

## 5. Territory, storage and migration

**Storage model:** the world is generated from a seed, so a save stores only **deltas** from the generated map: tiles whose owner, troops, power or buildings differ from the seed output. A typical save then holds hundreds of records, not 10,201. The full map is never serialized.

**Migration paths:**
1. **Prototype saves (72 tiles, `kc3_sovereign_save_v5`/`v6`):** map every legacy tile to `t_<col>_<row>`. Keep its owned state. Generate the remaining squares from the seed. Translate every reference in marches and other records. Verifier must confirm no owned tile is lost.
2. **Current build saves (100 tiles, 10×10, `tile_<row>_<col>`):** same rename, then the delta model.
3. Migration is one-way, and the original save is kept under its old key until the new save is written successfully.

**Towers (from the sketch, approximate):**

| Tower | Sketch (fraction) | Proposed symmetric coordinate |
| :--- | :--- | :--- |
| Top-left quadrant | 0.22, 0.22 | (22, 22) |
| Top-right quadrant | 0.77, 0.22 | (78, 22) |
| Bottom-left quadrant | 0.23, 0.77 | (22, 78) |
| Bottom-right quadrant | 0.74, 0.73 | (78, 78) |
| Centre pair | 0.46, 0.51 and 0.52, 0.51 | (46, 50) and (54, 50) |

The sketch is not symmetric. The proposal is symmetric about (50, 50), which keeps the win condition fair. See Decision D1.

**Win condition:** capture 4 of the 6 `mythical_tower` tiles. This replaces "eliminate all NPC factions" as the proposed rule. Still requires confirmation.

## 6. Rendering design (proposal, unverified)

- Terrain: one heightfield split into chunks of 16×16 territories (≈ 7×7 = 49 chunks for 101×101).
- Territory plates and markers: one `InstancedMesh` per biome per chunk, not per tile.
- Biome transitions: blend weights in the terrain shader, computed from distance to biome boundaries. Gameplay biome stays one value per territory.
- LOD: three levels per chunk (full, reduced, far). Frustum culling per chunk.
- Selection and hover: a single raycaster against the chunked heightfield, mapping hit points to `(x, y)`. Conquest logic never reads geometry.
- Acceptance thresholds to measure in a browser before approval: frame time under 16.7 ms on a reference desktop, draw calls under 300 at default zoom, no per-tile mesh allocations during play.

## 7. Child contract impact

| Child | Change |
| :--- | :--- |
| SD-01 Infrastructure | Coordinate schema, delta save format, migration module |
| SD-02 World rendering | Chunked terrain, instancing, LOD, biome blending |
| SD-03 Territory conquest | Spatial index, tower tiles, 4-of-6 win condition |
| SD-04 Combat | Creature stat port (`creatureBalance.ts`), unchanged otherwise |
| SD-05 Creatures | Stats source per Decision D4 (already answered: port prototype formulas) |
| SD-06 Assets | Instancing-compatible materials and models |
| SD-07 UI | Selection and camera at 101×101 scale |
| SD-08 QA | Performance budget tests, migration tests from 72 and 100 saves |
| SD-V Verifier | Coordinate bounds, ID format, delta-save round trip, migration equivalence, golden replay regenerated |

Every child keeps its write scope. The verifier change adds checks; it does not weaken existing ones.

## 8. Decisions required

- **D0 — Approve CR-001 scope** (Section 2). Implementation does not start without this.
- **D1 — Tower placement:** symmetric proposal (above) or the sketch positions as drawn.
- **D2 — Centre row and column:** the 101st row and column make the four biomes unequal. Options: assign the centre line to the north/west side (asymmetric counts above), or to a separate "crossroads" band that is not a biome.
- **D3 — Win condition:** 4-of-6 towers confirmed, and what happens to the NPC factions when they lose all towers.

## 9. Not yet verified

- Browser rendering performance and LOD behaviour.
- Save migration round trip on real 72-tile and 100-tile saves (needs a sample save file).
- Golden replay for the new world (must be regenerated after D1–D3).


## 10. Decision record and status

| ID | Decision | Source |
| :--- | :--- | :--- |
| D0 | Scope of CR-001 approved; proceed | Owner |
| D1 | Towers symmetric: corners (22,22), (77,22), (22,77), (77,77); centre pair. Translated to 0-99: centre pair at (46,49) and (53,49) | Owner (layout); translation by builder |
| D2 | Grid is 100 x 100 (coordinates 0-99), axes between squares, 10,000 territories, 2,500 per biome | Owner |
| D3 | Win: hold 4 of the 6 mythical towers | Owner |
| D4 | Creature combat stats: port the prototype's creatureBalance.ts formulas | Owner |

**Implemented:** world generator for 100 x 100 with t_<x>_<y> IDs, quadrant biomes, six towers, and a legacy ID migration function. Simulation with a coordinate index, a tower tile type, and tower victory. Updated tests (51), verifier (29 checks), golden replay, and Unity data.

**Still open:** chunked terrain and instancing; delta-based saves and a v7 save key; wiring migrateTileId into the client for march records; the React client, whose RealmMap creates one mesh per territory and must not run at this scale; creature combat (D4) not yet ported into the simulation; and the multiplayer model (B5).


## 11. Renderer status

**Built**
- `src/rendering/chunking.ts`: pure chunk math. 7 x 7 chunks of 16 x 16 territories (edge chunks hold 4), tile-to-chunk mapping, world-to-territory picking, LOD by distance, frustum-free visibility by radius, and biome blending across the axes. Verified by 13 unit tests under Node.
- `src/rendering/ChunkedTerrain.ts`: Three.js renderer on top of the math. Per chunk: three terrain LOD meshes, one instanced plate mesh coloured by owner, and a frustum-culled LOD switch.

**Measured (exact, from the segment rule)**
- Terrain vertices if every chunk were at full detail: 42,849. At LOD 1: 11,449. At LOD 2: 3,249.
- Draw calls: at most 2 per chunk (98 total), plus tower markers (not yet built). The CR target was under 300.

**Not verified**
- `ChunkedTerrain.ts` has not been type-checked or run. This sandbox has no `three` package and no browser. It needs a build and a browser run before it is trusted.
- Frame time, memory, and LOD switching cost are not measured.
- Nothing is wired into the React client. `RealmMap.tsx` still builds one mesh per territory and must not run at this scale.

**Known problem: height field**
`getWorldTerrainHeight()` in `mathUtils.ts` was tuned for the old ~120-unit map. Its ridges and hills sit near the origin, and the world is now ±600 units. The renderer takes the height function as an input, so the field can be replaced without touching the chunk code. The replacement is a task of its own.

**Still open:** type-check and browser run of the Three.js layer; a new height field for the 100 x 100 world; tower markers and landmarks; wiring into the client; delta-based saves; the creature port (D4); and the multiplayer model (B5).


## 12. Creature stats (D4)

**Done.** The prototype's `creatureBalance.ts` is pure TypeScript, so its functions are used directly rather than rewritten. Exported to Unity as integer data:
- `unity_handoff/data/creature_stat_table.json`: hp, atk, def, spd, combat rating, EXP and gold cost for tiers 1-6 x rarities x levels 1-50 (36 curves).
- `unity_handoff/data/creature_synergy_rules.json`: element bonuses (2 minor +10%, 3 major +20%, 4 primal +30%) and the 12 family bonuses.
- 72 tests pass, including agreement with the live prototype functions.

**Corrections to the earlier premise**
- The prototype has **no creature point cost**. The 15-point lineup budget applies to commander, battalion and support cards only. Creatures enter through element and family synergies and commander bonds.
- The CSV has no star rank. The table assumes stars = tier, which is the prototype's default when stars is unset. Confirm this.
- The prototype rounds with `Math.round`. For non-negative values this equals `floor(x + 0.5)`, which is the rule the C# side must use.

**Not done.** How creatures take part in combat. The simulation still uses troops only, and creature combat needs a decision (section 13).


## 13. Open decisions on creature combat

- **C1 — How creatures enter combat:** (a) creatures form squads inside an army, attacking with element and family matchups applied per pair; (b) creatures only add synergy bonuses to troop stats, as the prototype does today; (c) defer creatures until the solo loop is playable.
- **C2 — Lineup cost for creatures:** none (bonuses only), tier number, or rarity-based.
