# NAVI-SD-OMEGA-001 — CR-002: Creature Combat, Inspection Report

**Status:** INSPECTION COMPLETE. Implementation stopped. No game code changed in this step.
**Scope asked:** creatures as individual combat units, each with its own deployment cost and formation-slot requirement, derived from the prototype's authoritative data; 15 formation slots per army; independent movement, basic attacks, active skills with cooldowns, passives with conditions; multi-slot creatures act as one entity; validate slots and cost against limits; keep the 9,999 cap unless reconciled; `creatureBalance.ts` is the balance authority; SD-04 and SD-05 share one versioned schema.
**Rule from the owner:** do not invent slot requirements or costs. Report ambiguity or incompatibility rather than replace prototype rules with assumptions.

---

## 1. What the prototype actually defines

| Requirement | Prototype status | Where it lives |
| :--- | :--- | :--- |
| 15-point lineup budget | **Exists.** Budget is points, not slots. Points come from commander, battalion and support cards only. | `lineupUtils.ts` lines 81-83; `CardDeck.tsx` ("Max 15 Points") |
| Card slots | **Exists.** Three: Commander (slot 1), Vanguard Battalion (slot 2), Support (slot 3, optional). | `CardDeck.tsx` 527-687; `RealmMap.tsx` 1567-1687 |
| Creature formation slots | **Not defined.** CreatureCard has no slot field. The CSV has no slot column. | `types.ts` CreatureCard; CSV header |
| Creature deployment cost | **Not defined.** `creatureBalance.ts` defines stats, EXP and gold per level, synergies and commander bonds, but no deployment cost. | `creatureBalance.ts` (whole file) |
| Formation placement | **Stances only.** Balanced, aggressive and defensive scale army power and speed. The 5×5 "formation field" is a visual preview with no placement rules. | `territorySystem.ts` `resolveTerritoryCombat`; `RealmMap.tsx` 1871-1941 |
| Creature movement | **Not defined.** Marching is army-level. | `RealmMap.tsx` march objects |
| Creature basic attacks | **Not defined.** Combat is army-level. | `resolveTerritoryCombat` |
| Creature active skills | **Name only.** Each creature has one `signatureAbility` string (48 distinct values across 432 creatures). No effect, trigger or cooldown. | CSV "Signature Ability" column |
| Creature passive skills | **Not defined.** The family-specialty column is text (12 values). | CSV "Family Specialty" column |
| Cooldowns and active/passive types | **Exist for commander skills only.** `CardSkill` has `type`, `cooldown` (seconds) and `damageMultiplier`. | `types.ts` CardSkill; `initialData.ts` |
| Multi-slot creatures | **Not defined.** No size data. | — |
| Creature participation in combat | **None.** `resolveTerritoryCombat` uses the commander's attack and troop count only. Creature stats are used by the Bestiary display and starting stats only. | `territorySystem.ts` 116-170; `BestiaryModal.tsx`; `creaturesLoader.ts` |
| Element and family matchup tables | **Exported but unused.** No code reads `element_matchups` or `family_matchups`. `combat_rules.csv` is marked "PROPOSED. No battle simulation / balance QA performed." | CSV files; zero references in `src/` |
| Troop cap 9,999 | **Exists.** `BASE_TROOP_CAP` plus INT × 85/100, plus research, plus skills. It caps troop count, not cost or slots. | `RealmMap.tsx` 194-216; `CardDeck.tsx` 409 |
| Shared creature and combat schema | **Does not exist.** CreatureCard and CommanderCard are separate TypeScript interfaces. | `types.ts` |

## 2. Incompatibilities with the request

1. **"15 formation slots" vs "15-point budget".** The prototype's 15 is a point budget. A slot count is a different rule. Both cannot apply to the same thing without a decision.
2. **Creatures as individual units vs army-level combat.** The prototype's creatures do not fight. Making them individual combat units changes what the 9,999 cap and the troop count mean.
3. **"Derive from the prototype" vs unused and proposed matchups.** The matchup tables are proposed, not prototype behaviour. They cannot be called authoritative from the prototype.
4. **Cost for creatures.** The request assumes a per-creature deployment cost. The prototype has none.
5. **Skill behaviour.** Creature abilities have names only. Defining effects, triggers and cooldowns would be new design work, not a port.

## 3. Scale of the data gap

- 432 creatures. 48 distinct signature-ability names, each needing an effect, trigger, cooldown and target rule.
- 12 family specialties, each needing a passive condition.
- 6 combat roles and 36 archetypes, with no slot or cost mapping.
- No slot size, cost, or multi-slot flag for any creature.

Implementing the request as written would require inventing about 432 slot values, 432 costs, and roughly 60 skill definitions. The owner has ruled that out.

## 4. Decisions needed before SD-04 and SD-05 can start

- **K1 — Slots or points?** Does "15" mean formation slots (new rule) or the existing 15-point budget? If slots, the existing card-point budget needs its own rule.
- **K2 — Source of slot and cost values.** Who provides the per-creature slot requirement and deployment cost? Options: a data table supplied by the owner; a rule derived from tier, rarity or role (new design, needs approval); or defer creatures.
- **K3 — Creature combat behaviour.** Basic attack formula, movement model (per army or per creature), and the effect definitions for the 48 signature abilities and 12 family passives.
- **K4 — Matchup authority.** Should the proposed element and family matchups become the combat rule? If yes, they need balance QA first.
- **K5 — Troop cap.** Keep the 9,999 cap on troop count, or re-express it through creature slots and cost?
- **K6 — Multi-slot creatures.** Which creatures are large, and how many slots each takes.
- **K7 — Shared schema.** Approve the versioned creature-and-combat schema as a design that SD-04 and SD-05 both implement. Its fields depend on K1–K6.

## 5. Recommendation

Do not start SD-04 or SD-05 combat code yet. The smallest unblocking step is the owner answering K1 and K2. The skill definitions (K3) are the largest piece of design work and can follow once the rule is settled.

Creature stats (`creatureBalance.ts`) are already exported to Unity as integer tables, so the stat side is ready.
