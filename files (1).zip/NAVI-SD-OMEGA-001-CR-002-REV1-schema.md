# NAVI-SD-OMEGA-001 — CR-002 REV1: Creature Combat Schema v1

**Status:** PROPOSAL for approval. Shared by SD-04 (combat) and SD-05 (creature design).
**schema_version:** `creature-combat/2` (v1 extended by owner approval; v2 additions listed in section 15)
**Rules reference:** NAVI-SD-OMEGA-001-CR-002-REV1-creature-only-combat.md

Conventions: integers only. Ids are ASCII. Enumerations are closed sets; an unknown value is a validation error. Unknown fields are rejected in v1 (strict).

---

## 1. Enumerations

| Name | Values |
| :--- | :--- |
| `Element` | Fire, Water, Earth, Wind, Lightning, Frost, Nature, Shadow, Light, Arcane, Poison, Void |
| `Family` | Dragons, Undead, Elementals, Demons, Beasts, Celestials, Swarmkin, Abyssals, Humanoids, Giants, Fae, Mechanicals |
| `Rarity` | common, uncommon, rare, epic, legendary, mythical |
| `SizeClass` | small (1), medium (2), large (3), huge (4), colossal (6) — **pending A1** |
| `Formation` (army) | front, back — **pending A3** (row names) |
| `Trigger` | battle_start, round_start, on_attack, on_hit, on_damaged, on_death, aura |
| `EffectType` | damage, heal, buff, debuff, move |
| `Side` | attacker, defender |

## 2. CreatureDef (SD-05 owns; SD-04 reads)

| Field | Type | Rule |
| :--- | :--- | :--- |
| `creature_id` | string | Matches `SD-####`. Unique across the catalog. |
| `name` | string | From the catalog. |
| `family` | Family | From the catalog. |
| `element` | Element | From the catalog. |
| `rarity` | Rarity | From the catalog. |
| `tier` | int 1–6 | From the catalog. |
| `size_class` | SizeClass | **SD-05 assigns.** Must match `footprint` size. |
| `footprint` | `{ width: int, height: int, cells: [[dc, dr], ...] }` | Cells are relative to the anchor. Connected. Within 5 × 3 after placement. |
| `stat_source` | `{ table: "creature_stat_table", version: string }` | Stats come from the exported table, never recomputed. |
| `movement` | int ≥ 0 | Cells per turn. **SD-05 assigns.** |
| `range` | int ≥ 1 | Manhattan cells. **SD-05 assigns.** |
| `basic_attack` | `{ damage_source: "ATK" }` | Fixed. The damage rule is in the rules document §8. |
| `skills` | list of SkillRef, max 2 | **SD-05 assigns.** May be empty. |
| `passives` | list of PassiveRef | **SD-05 assigns.** May be empty. |
| `synergy_tags` | list of string | Feeds calculateCreatureSynergies. |

## 3. SkillDef

| Field | Type | Rule |
| :--- | :--- | :--- |
| `skill_id` | string | Unique. |
| `name` | string | — |
| `kind` | `active` | Passives use PassiveDef. |
| `cooldown_rounds` | int ≥ 0 | **Pending A4.** Rounds, not seconds. |
| `targeting` | enum: `nearest_enemy`, `self`, `ally_in_range`, `all_allies`, `all_enemies` | Closed set. |
| `condition` | enum: `always`, `hp_below_half`, `enemy_in_range` | Closed set. |
| `effects` | list of Effect, max 3 | Each effect has an `EffectType` and integer parameters. |

## 4. PassiveDef

| Field | Type | Rule |
| :--- | :--- | :--- |
| `passive_id` | string | Unique. |
| `trigger` | Trigger | Closed set. |
| `condition` | as SkillDef.condition | — |
| `effects` | list of Effect, max 3 | — |

## 5. Effect

| Field | Type | Rule |
| :--- | :--- | :--- |
| `type` | EffectType | Closed set. |
| `stat` | enum: `hp`, `atk`, `def`, `spd`, `none` | Used by buff and debuff. |
| `amount` | int | Basis points for buffs and debuffs (10000 = no change). |
| `duration_rounds` | int ≥ 0 | 0 = instant. |

## 6. ArmyLoadout (player or NPC)

| Field | Type | Rule |
| :--- | :--- | :--- |
| `army_id` | string | Unique. |
| `owner` | string | Faction id or `player`. |
| `origin_tile_id` | string | `t_<x>_<y>`. |
| `commander_id` | string or null | Optional. Not a formation occupant (A7). |
| `placements` | list of Placement | Max 15 occupied positions in total. |

**Placement**

| Field | Type | Rule |
| :--- | :--- | :--- |
| `instance_id` | string | Unique within the army. |
| `creature_id` | string | Refers to a CreatureDef. |
| `level` | int 1–50 | — |
| `anchor` | `{ col: int 0–4, row: int 0–2 }` | Footprint cells must fit inside the grid. |

## 7. CreatureInstance (battle state)

| Field | Type | Rule |
| :--- | :--- | :--- |
| `instance_id` | string | From the placement. |
| `current_hp` | int ≥ 0 | 0 = dead. |
| `cooldowns` | map skill_id → int ≥ 0 | Rounds remaining. |
| `alive` | bool | Derived from `current_hp > 0`. |

## 8. BattleState

| Field | Type | Rule |
| :--- | :--- | :--- |
| `schema_version` | string | `"creature-combat/1"`. |
| `round` | int ≥ 0 | — |
| `max_rounds` | int | Pending A9. |
| `initiative_order` | list of instance_id | SPD desc, then instance id asc. Fixed for the battle. |
| `sides` | `{ attacker: [CreatureInstance], defender: [CreatureInstance] }` | — |
| `event_hash` | string (8 hex) | FNV-1a of the round's event log. |

## 9. CombatEvent

| Field | Type | Rule |
| :--- | :--- | :--- |
| `round` | int | — |
| `actor` | instance_id | — |
| `action` | enum: `move`, `attack`, `skill`, `passive`, `death`, `victory` | Closed set. |
| `target` | instance_id or null | — |
| `from` / `to` | anchor or null | For move. |
| `amount` | int | Damage or heal, or 0. |

## 10. Validation rules (V1–V9)

- **V1.** Every footprint cell is inside the 5 × 3 grid.
- **V2.** No two footprints overlap, in any army.
- **V3.** Total occupied positions ≤ 15.
- **V4.** `size_class` matches the footprint size (1, 2, 3, 4 or 6).
- **V5.** Footprint cells are connected.
- **V6.** `instance_id` is unique within the army. A creature appears in at most one army.
- **V7.** Level 1–50. Cooldowns are integers ≥ 0.
- **V8.** Enumerations are closed. Unknown values and unknown fields are rejected.
- **V9.** No field named `troop*`, `battalion*`, `unit*`, `cap*`, or `points*` appears in any v1 object.

## 11. Example (illustrative values, not approved data)

```json
{
  "schema_version": "creature-combat/1",
  "creature_id": "SD-EXAMPLE",
  "name": "Example Creature",
  "family": "Dragons",
  "element": "Fire",
  "rarity": "rare",
  "tier": 3,
  "size_class": "large",
  "footprint": { "width": 3, "height": 1, "cells": [[0,0],[1,0],[2,0]] },
  "stat_source": { "table": "creature_stat_table", "version": "1" },
  "movement": 2,
  "range": 1,
  "basic_attack": { "damage_source": "ATK" },
  "skills": [],
  "passives": [],
  "synergy_tags": ["example"]
}
```

The id `SD-EXAMPLE` is not a roster creature. Every value shown is a placeholder, including the size class, footprint, movement, range, skills and passives, until SD-05 assigns them.

## 12. Versioning

- A schema change that adds a required field, changes an enumeration, or changes a rule bumps the major version: `creature-combat/2`.
- Saves store `schema_version`. A reader that does not know the version refuses to load it and does not guess.
- Migration from v6 saves is in the migration plan, not here.


## 13. Implementation notes (reference build)

- **V3 is implied.** The 5 x 3 grid holds exactly 15 positions, so any placement inside the grid satisfies V3. The check is kept as a guard.
- **V4 holds by construction.** The footprint is derived from the size class and is not a separate input.
- **Geometry (new, to confirm).** Both armies share a 5 x 6 field. The attacker's army row r sits on field row 2 - r; the defender's on field row 3 + r. Columns align.
- **Provisional values.** MAX_ROUNDS = 20 (A9 "to be set"). Timeout tiebreak: greater remaining HP share, cross-multiplied; equal shares favour the defender.
- **Not implemented in v1.** Element and family matchups (K4, off), commanders, passives beyond battle_start stat buffs, effects beyond damage and heal, and capture (handled in the world layer).
- **Reference code:** src/combat/schema.ts, src/combat/battle.ts; tests/creature_combat.test.ts (21 tests). Full suite: 93 tests pass.


## 14. World layer (SD-03) — reference implementation

Implemented in `src/world/rosters.ts` (7 tests, 100 in the full suite):
- **Staging (A8):** creatures on owned territories within radius 2 of the origin, nearest first. A territory may be emptied.
- **Capture (A8):** a won attack makes the surviving attackers the territory's roster.
- **Failed attack (owner decision):** survivors return to the origin territory.
- **Emptied territory (owner decision):** it keeps its owner until conquered. An attack on an emptied enemy territory takes it without a battle.
- **Blocker:** attacks on neutral territories are refused until the neutral-roster rule is approved.


## 15. Schema v2 additions (approved; builder rules pending owner review)

- **Effect types added:** `dot` (percent of max HP each round for `durationRounds` rounds, ignores evasion and blindness), `shield` (absorbs up to percent of max HP for `durationRounds` rounds), `evade` (next N incoming attacks miss), `blind` (next N attacks by the target miss), `root` (cannot move for N rounds), `stun` (loses its turn for N rounds), `teleport` (moves to the free square within two steps closest to the nearest enemy).
- **Targeting added:** `chain` (nearest enemy takes full damage, the next takes half).
- **Stat added:** `skill` on aura passives (team skill damage multiplier, basis points).
- **Passive trigger:** `battle_start` may grant `evade` charges.
- **Event actions added:** `miss`, `dot`, `status`.
- **Determinism:** none of the above uses randomness. Each rule is integer and ordered by the existing initiative and id ordering.
