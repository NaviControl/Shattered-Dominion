# NAVI-SD-OMEGA-001 — SD-05 Draft for Review

**Status (owner, "approve all"):** Sections 1, 2 and 5 APPROVED. Section 3 effects APPROVED, including the 13 schema-v2 abilities, which are now built under creature-combat/2 with builder-proposed rules (see the schema, section 15). Section 4 passive mapping APPROVED, except the troop-increase category, which conflicts with the approved creature-only design and is awaiting a decision.
**Files:** `unity_handoff/data/sd05_draft_assignments.csv` (432 rows, one per creature), and the neutral roster draft in `src/data/neutralRosters.draft.ts`.

Every value here is derived from a rule stated below. The owner's instruction was not to invent slot requirements or costs, so each rule is listed for approval or change.

## 1. Size class (from tier) — APPROVED

| Tier | Size class | Footprint |
| :--- | :--- | :--- |
| 1 | small | 1 position |
| 2 | medium | 2 |
| 3 | large | 3 |
| 4 | huge | 4 |
| 5 | huge | 4 |
| 6 | colossal | 6 |

Tier 5 shares Huge with tier 4 because there are five size classes and six tiers. This is a choice to confirm.

## 2. Movement and range (from combat role) — APPROVED

| Role | Movement | Range |
| :--- | :--- | :--- |
| Skirmisher | 3 | 1 |
| Assassin | 3 | 1 |
| Vanguard | 2 | 1 |
| Controller | 2 | 3 |
| Support | 2 | 2 |
| Siege | 1 | 4 |

## 3. Active skill — effects APPROVED by owner (35 runnable now; 13 need schema v2, not approved)

The owner delegated the effects to the builder. All 48 are drafted in `unity_handoff/data/signature_abilities_DRAFT_effects.csv`, marked DRAFT.

The battle engine now runs 35 of the 48 as drafted. These cover single-target and area damage, heals on self, on an ally in range, or on all allies, buffs and debuffs on ATK, DEF and SPD with durations, and knockback.

The other 13 need a schema change (creature-combat/2), which needs your approval: damage over time (Toxic Bite, Noxious Cloud, Plague Bloom), shields (Radiant Ward), evasion and accuracy (Dread Veil, Phase Shift, Blindside), roots and stuns (Vine Snare, Ice Prison), chain targeting (Arc Chain), and self-teleport (Aether Rift). Their ascendant forms are in the list too.

Ascendant forms: damage and heal amounts x1.5; buff and debuff durations +1 round.

## 4. Passives

Owner's categories: stat increases, team skill damage, healing, and troop increase.

- **Stat increases:** built (battle-start buffs to ATK, DEF or SPD).
- **Healing:** built (round-start heal, percent of max HP).
- **Team boost:** built as an aura that buffs allies in range. Exact team skill damage needs schema v2.
- **Troop increase:** NOT built. Troops are removed by the approved creature-only design (CR-002 REV1), so this category conflicts with it. Needs your decision.

The draft mapping of each family specialty to a passive is in `unity_handoff/data/family_specialty_passives_DRAFT.csv`, pending your approval.

## 5. Neutral rosters — APPROVED (one roster per territory type, five wild-node types)

The rule was approved: each neutral territory type is garrisoned by a fixed roster. The draft picks creatures by tier and ID order.

| Territory type | Roster | Tier | Anchors |
| :--- | :--- | :--- | :--- |
| farmland | SD-0001, SD-0002, SD-0003 | 1 | row 0, columns 0–2 |
| lumber_mill | SD-0004, SD-0005, SD-0006 | 1 | row 0, columns 0–2 |
| stone_quarry | SD-0007, SD-0008, SD-0009 | 1 | row 0, columns 0–2 |
| iron_vein | SD-0010, SD-0011, SD-0012 | 1 | row 0, columns 0–2 |
| mana_monolith | SD-0013, SD-0014, SD-0015 | 1 | row 0, columns 0–2 |
| monster_lair | SD-0031, SD-0032 | 4 | columns 0 and 2 |
| ancient_ruin | SD-0015, SD-0016 | 2 | columns 0 and 2 |
| mythical_tower | SD-0025, SD-0026, SD-0027 | 3 | column 0, rows 0–2 |

Open questions:
- **Creature choice.** The picks are the first creatures by ID in each tier. A design choice would be to pick by element or family per territory.
- **Creature level.** Each neutral creature is set to level 5 × territory level (level 1–6 gives creature levels 5–30). This is a placeholder rule.

## 6. What I need from you

1. Approve, change, or reject the size and movement/range rules (sections 1 and 2).
2. Fill in `signature_abilities_TO_SPECIFY.csv` with an effect for each of the 48 signature abilities.
3. Decide whether passives come from the family specialty, and if so how.
4. Confirm the neutral rosters (section 5) and the creature level rule.

Once approved, the draft becomes the data. The schema and rules documents already accept it without change.

**Not started:** migration (deferred until a playable build exists, per your decision).


## 7. Status after "approve all"

- **Catalogue built:** `src/combat/catalog.ts` loads all 432 creatures from the approved files: 300 with a runnable signature ability, 396 with a passive. A test runs every creature through a battle.
- **Not built, awaiting schema v2 (approved in principle):** damage over time, shields, evasion, accuracy, roots and stuns, chain targeting, self-teleport, and exact team skill damage. Each needs a deterministic rule before code: for example, how evasion triggers without randomness, and whether root and stun last whole rounds.
- **Not approved, needs decision:** the troop increase passive. Troops were removed by the approved creature-only design (CR-002 REV1). Choose to drop it, or replace it with a stat or heal passive.
- **Passives for "Evasion / illusions":** none until schema v2.


## 8. Status: schema v2 built

- All 432 creatures have a runnable signature ability and a passive in the catalogue (`src/combat/catalog.ts`).
- Verifier (`npm run verify`) passes 34 of 34, including five catalogue checks.
- Test suite: 125 tests pass.
- Still open: the troop-increase passive (conflicts with the approved creature-only design); the per-specialty mapping of team skill damage (no specialty is mapped to it yet); the builder-proposed schema-v2 rules, pending your review.
- Not started: a playable solo match using creature armies, and the migration (deferred until a playable build).


## 9. Requested changes (pending decisions)

- **Team skill damage as a team increase, from synergies and passives:** built. At battle start, each side's element and family synergies (prototype rules) add ATK, DEF or SPD to the members. Passive auras still add team boosts. Tests: 127 pass.
- **Troop increase becomes a unit increase, above the 9,999 cap, scaled by creature intelligence:** NOT built. The approved creature-only design removed troops and the cap. Creatures have no intelligence stat; the prototype's intelligence feeds the commander's troop-cap formula. Needs your decision on the stat and the rule.
- **Free stat points on level-up:** NOT built. The prototype has no point allocation for creatures. Needs points per level and any caps.
- **Skill durations of N = 1 round x skill level:** NOT built. Creatures have no skill level in the prototype. Needs confirmation of which effects it applies to and how a skill levels up.


## 10. Owner updates: creatures only, eight baseline stats

- No troops and no commanders. The unit increase, the 9,999 cap and the intelligence-based rule are removed.
- Eight baseline stats raised on level-up: HP, attack, defense, speed, movement, range, skill power, team synergy. Built in `src/combat/stats.ts`.
- Open: points per level; whether creatures get more than one active skill (the schema allows two); the "N = 1 round x skill level" duration rule, which needs a skill level.


## 11. Owner answers (level-up, skills)

- **Level-up points: 5 per level.** Built (`POINTS_PER_LEVEL`).
- **Skill levels: separate from creature levels, through their own points.** Built with two builder assumptions to confirm: one skill point per skill level, and a maximum level of 10.
- **Duration: N = 1 round x skill level.** Built: a skill's level sets the rounds for its duration-based effects. Buffs and debuffs now last N rounds after they are applied.
- **Active skills: two for high-rarity creatures only.** The slot limit is built. Two assumptions to confirm: epic, legendary and mythical are high-rarity; and the source of the second active skill is not yet defined, so no creature receives one yet.
- Open: the skill-point cost per level, which effects use the duration rule, and the second-active source.


## 12. Owner answers (round 2)

- **High-rarity (two actives): epic, legendary and mythical.** Built.
- **Second active skill: from the same archetype.** Built: the first runnable ability in the creature's archetype that differs from its own, in creature-ID order.
- **Skill level cost: 1 point per level.** Built.
- **Duration rule changed from N = 1 + level x 0.5 to whole rounds: N = 1 + floor(level / 2).** Built. Alternatives in the decision list below.
- Creatures now carry an archetype field in the SD-05 data.

- **Duration rounding confirmed by owner: N = 1 + floor(level / 2).** Level 1-2 = 1-2 rounds; level 10 = 6 rounds.


## 13. Playable match (builder draft)

- Built in `src/match/match.ts`: formation packing (15 positions), player attacks from staged creatures, NPC turns, tower victory (4 of 6), defeat when the player owns no territory, and a round cap (40, provisional).
- Still open for owner approval: the starting roster for the player's territories, the NPC citadel rosters, and the NPC policy (attack when 6/5 stronger, weakest target first).
- Tests: 147 pass in total.
- Not done: a graphical client, and the world-map integration that drives the match from the UI.


## 14. Owner rules for match start and NPCs (built)

- **Starter roster:** the player's first creature is drawn from the starter pack at first login. The pull uses the approved rarity table (50.5 / 27 / 14 / 6 / 2 / 0.5 %), then an equal chance within the rarity, seeded by the player. ASSUMPTION: the pack draws from all 432 creatures.
- **NPC citadel rosters:** set by the land's level (tier, capped at 6) and terrain (element). The biome-to-element mapping is a builder draft: sol heights = Light, ignis caldera = Fire, frost wastes = Frost, abyssal marshes = Shadow. To confirm.
- **NPC spread:** each faction acts on a fixed schedule, every 3 turns, staggered by faction index. ASSUMPTION: 3 turns.
- **Not overpowering:** each NPC attack uses the strongest army within 150% of the player's strongest roster power. A faction with no creature under the cap does not attack. To confirm the 150% figure.


## 15. Owner confirmations (match start and NPCs)

- NPC citadel elements by biome, confirmed: sol heights = Light, ignis caldera = Fire, frost wastes = Frost, abyssal marshes = Shadow.
- NPC spread, confirmed: every 3 turns, staggered by faction.
- NPC attack strength, confirmed: up to 150% of the player's strongest roster.
- Starter pack, confirmed: all 432 creatures, pulled with the approved rarity table.
