# NAVI-SD-OMEGA-001 — CR-002 REV1: Migration and Compatibility Plan

**Status:** PROPOSAL for approval. Nothing is migrated, deleted or changed by this document.
**Rule from the owner:** do not delete legacy data or migration code until compatibility is verified. Do not corrupt existing saves silently.

---

## 1. Dependency inventory

Counts are from a text search of `src/` at the current build. "Refs" counts lines that mention the term.

| Area | Where | Refs | Disposition |
| :--- | :--- | :--- | :--- |
| Troop type and unit state | `types.ts` `TroopUnit`, `TroopFormation`, March `troopType`/`troopCount` | 18 | **Retire.** Replace with creature placements. |
| Troop state and training | `App.tsx` `troops` state, `handleTrainTroops`, `INITIAL_TROOPS` | 53 (App) | **Retire.** Creatures replace recruitment. |
| Barracks UI | `CitadelBase.tsx` "Troops" tab (`onTrainTroops`) | 15 | **Retire.** Replace with a roster view (SD-07). |
| Army dispatch UI | `RealmMap.tsx` lineup modal, troop type and count, Max 15 Points text, 9,999 text | 70 | **Replace** with the 5 × 3 formation editor (SD-07). |
| Card deck UI | `CardDeck.tsx` battalion and support slots, points, "Musters", troop cap text | 46 | **Retire** battalion and support; **replace** points with formation view. |
| Lineup points | `lineupUtils.ts` `MAX_LINEUP_POINTS`, `calculateLineupPoints` | 28 | **Retire.** No point budget. |
| Troop capacity | `lineupUtils.ts` `BASE_TROOP_CAP`, `calculateTroopCapacity` | — | **Retire** (the 9,999 cap). |
| Muster yields | `lineupUtils.ts` `calculateCollectedCardTroopYields`; `App.tsx` 12-second loop and manual muster | — | **Retire.** Troops no longer muster. |
| Squad combat | `combatEngine.ts` troop-squad functions; `FORMATION_TACTICS_DATA` | 12 | **Retire.** Replace with the creature round engine. |
| Territory combat | `territorySystem.ts` `resolveTerritoryCombat`, `troopCount × 12` | 4 | **Retire.** |
| Commander troop fields | `creatureBalance.ts` `calculateCommanderStatsAtLevel` (`troopCapacity`), `evaluateCommanderBalance` (`troopYieldIndex`) | 14 | **Retire** the troop fields. Keep the commander's non-troop stats if approved. |
| Commander data | `initialData.ts` `troopGeneration` on commanders and unit cards | 44 | **Archive.** Unused in v7. |
| Tile garrisons | `types.ts` `garrisonTroops`; `worldGenerator.ts` | 8 | **Replace** with creature rosters (A8). **Blocker** for migration. |
| Save state | `gameStorage.ts` `troops`, `unitCards`, `marches`, tile `garrisonTroops`, commander troop fields | 2 + fields | **Migrate** per §3. |
| Solo simulation | `src/sim/engine.ts`, `bot.ts` (troop model) | 42 + 1 | **Legacy.** Replace after the creature engine is approved. |
| Unity handoff spec | `unity_handoff/SPEC.md`, troop sections | — | **Deprecated** (see §6). |
| Quests and campaigns | `initialData.ts` quests and campaign missions | not yet searched | **Check** for troop objectives (G6). |

**Not yet searched:** quest and campaign text that refers to troops. This must be done before implementation (gate G6).

## 2. Systems that keep working

- The 100 × 100 world, its coordinates and tile ids (`t_<x>_<y>`).
- The creature collection: ids, levels, EXP and gold costs, synergy rules.
- Tower victory (hold 4 of 6).
- Buildings and economy, except where they produce or consume troops (to be checked in the economy review).
- Save keys `kc3_sovereign_save_v5` and `v6`. They are read by the migration path. Neither is deleted.

## 3. Save compatibility

### 3.1 Versions

- **v5 and v6** (prototype): contain troops, battalions, marches with troop counts, tile troop garrisons, and commander troop fields.
- **v7** (creature combat): contains creature placements, creature-only marches, tile creature rosters, and no troop fields.
- v7 is written under a new key, `kc3_sovereign_save_v7`. The v6 key is left untouched until the v7 write has been read back and verified (gate G5). **[DECIDE A11]** Keep v6 readable for one release, then decide whether to remove it in a later change request.

### 3.2 Field-by-field disposition

| Field | Disposition | Reason |
| :--- | :--- | :--- |
| `creatures` (collection) | **Keep.** Ids, levels, EXP unchanged. | Creatures are the new combatants. |
| `cards` (commanders) | **Keep identity.** Drop cost and points use. Archive troop fields. | Commanders stay; their points budget is gone. |
| `unitCards` (battalions) | **Archive.** Not used in v7. | Battalion combat is removed. |
| `troops` (TroopUnit[]) | **Archive, do not convert.** See §3.3. | Converting troops to creatures would invent a rule. |
| `marches` | **Cancel any in transit.** Keep history records as archive. See §3.3. | Old marches are troop-based and cannot be resumed. |
| tile `garrisonTroops` | **Replace with a roster.** **Blocked** until A8 is decided. | Tile defence needs creature rosters. |
| tile `garrisonPower` | **Archive.** Defence now comes from the roster. | Same as above. |
| `economicCards`, `buildings`, `techs` | **Keep** unless the economy review says otherwise. | Not troop-based by definition, but their troop links must be checked. |
| `campaignMissions`, `claimedQuestIds` | **Keep.** Rewrite troop objectives after G6. | Objective text may refer to troops. |
| `playerLevel`, `leaderboard`, `factions`, `worldEvents`, `marketItems` | **Keep.** | No troop dependency found in the inventory. |

### 3.3 Options that need an owner decision (A10–A12)

- **Troops (A10).** Three options. (a) **Discard** with a one-time notice that troop counts are retired. (b) **Keep read-only** in an archive section, visible in the save and not used. (c) **Convert** to creatures. Option (c) would invent a conversion rule and is not proposed. The recommendation is (b), then (a) after one release.
- **Marches in transit (A10).** Cancel with notice. No troops are returned, because troops no longer exist. Confirm or name a refund.
- **Tile defence (A8).** Owned tiles keep their owner. Their defence needs a roster. The roster rule is a blocker: it cannot be filled without an SD-05 decision. Until it is decided, migration of owned tiles cannot be completed.

## 4. Migration procedure

1. **Read** the v6 save. If it is missing or fails to parse, leave it alone and report.
2. **Validate** the v6 state against its schema. Record any field that is unknown or out of range. Do not repair silently.
3. **Build** the v7 state from the disposition table in §3.2. Every dropped or archived field is listed in a migration report.
4. **Verify** the v7 state against `creature-combat/1` (rules V1–V9).
5. **Write** `kc3_sovereign_save_v7`.
6. **Read back** v7 and compare it with the in-memory state. Only on a match is the migration complete.
7. **Keep** v6 until the owner confirms (A11).
8. **Report** to the player: what was archived, what was cancelled, and what changed.

If any step fails, the v6 save is untouched and the failure is reported. Nothing is partially written.

## 5. Verification gates

Nothing legacy is deleted until every gate passes.

| Gate | Check |
| :--- | :--- |
| G1 | Owner-provided sample v5 and v6 saves load through the migration without exception. A field-by-field report is produced. **No real sample saves exist in the repository yet.** |
| G2 | Owned territories before and after migration are equal by count and by id. |
| G3 | Creature collection is identical before and after: ids, levels, EXP. |
| G4 | Migration is deterministic: the same input gives the same output hash. |
| G5 | The v7 read-back equals the in-memory migrated state. |
| G6 | Quests, campaigns and any other objective text that refers to troops has been found and rewritten. No dangling references. |
| G7 | Legacy paths are behind a flag. Tests run with the flag off and on. |
| G8 | Owner acceptance of the migration report on the sample saves. |

## 6. Deprecations and the existing test suite

- **Unity handoff spec** (`unity_handoff/SPEC.md`): sections on troop combat, the staging pool (B1), troops in marches, and troop garrisons are **deprecated**. A banner is added pointing to this plan.
- **Solo simulation** (`src/sim/`): the troop model and its golden replay are **legacy**. They keep passing until the creature engine replaces them. Their tests are not deleted until gates G1–G8 pass and the creature engine's tests exist.
- **Verifier** (`scripts/verify.ts`): troop-based checks are kept until replaced. New checks for creature schema validity (V1–V9) and footprint assignments are added with the creature engine.

## 7. Deletion policy

1. Legacy code is removed only in a **separate change request**, after G1–G8 pass and the owner approves.
2. Removal is staged: first disable behind a flag, then remove. A flag-off run must pass before the code is deleted.
3. Save readers for v5 and v6 remain for at least one release after v7 ships.
4. Archived data is kept inside the v7 save, not deleted, until the owner decides.

## 8. Decisions needed (this plan)

- **A10:** Troops disposition (archive recommended); marches in transit (cancel recommended).
- **A8:** Tile creature-roster rule. Blocker for owned-tile migration.
- **A11:** Keep v6 readable for one release (recommended); remove later.
- **G1 input:** Owner supplies real v5 and v6 save files for testing.
