# Shattered Dominion: questions to answer before the graphical game

The rules, data, and a terminal client are built and tested. These are the open decisions that a graphical game needs.

## Platform and client
1. Which client? Web (React and Three.js, using the existing prototype stack) or native (Unity, using the handoff package)?
2. Which devices? Desktop only, or desktop and mobile?
3. Which camera? Strategic overhead, or angled perspective? Free pan and zoom, or fixed levels?

## Map and battle interface
4. How does a player pick attackers? Drag creatures onto a formation grid, or pick from a list?
5. Do battles play out automatically with a log, or does the player watch an animated replay?
6. Should the player confirm each attack, or can attacks be queued across turns?
7. What does the player see of NPC armies before they attack?

## Economy (not designed yet)
8. Are there resources? If so, which ones, and where do they come from?
9. Is there anything to build, or do creatures and territories cover the whole economy?
10. Where do creature EXP and gold come from (battles, daily rewards, quests)?

## Progression and the starter
11. What does the first-login experience look like? Is the starter pull shown as a reveal?
12. Are there more starter creatures, or only the first pull?
13. What do players get for capturing towers, beyond victory?

## Save, accounts, and multiplayer
14. Is progress saved on the device only, or on an account?
15. Is the game single-player only for launch, or is multiplayer planned for a later release? (This decides the save and server design.)
16. What happens to prototype saves? Migration is deferred until a playable build exists. Do you have real saves to test with?

## Art and presentation
17. Which creature models ship at launch? The repository has GLB assets, but only for the prototype's landmarks.
18. Is there a visual style guide (colours, fonts, tone)?
19. Is there audio (music, battle sounds)?
20. What languages are needed?

## Remaining design items already flagged
21. Team skill damage: which passive specialty should carry it? None is mapped yet.
22. Schema v2 rules (dot, shield, evasion, blindness, root, stun, teleport, chain, team skill damage) are builder proposals. Please review them.
23. Playtest balance: starting garrisons, NPC aggression, and the 40-round cap are placeholders.
